#ifndef __MULTIPLICATION_H__
#define __MULTIPLICATION_H__

word8 multiplicationX(word8 byte);
word8 multiplicationXN(word8 byte, int n);

#endif // __MULTIPLICATION_H__
